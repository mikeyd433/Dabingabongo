# TouchSynth VST3 — Changelog / Handoff Notes

> Standalone notes so another session (APK-side or a fresh VST3 session) can pick
> up cold. **TouchSynth** is a JUCE 7 VST3 MPE synth (this repo) paired with a
> TouchSynth Android APK built in a *separate* chat. The APK sends MPE MIDI +
> settings SysEx over USB-C; the VST3 is **receive-only**. The shared contract is
> `TouchSynthSpec/PROTOCOL.md` (currently **v1.1**), mirrored in code as
> `Source/ProtocolConstants.h`. Non-negotiable wire facts: MPE Lower Zone
> (ch 1 master, ch 2–16 = 15 voices), pitch bend ±48 semitones (center `0x2000`),
> Y axis = CC74, SysEx `F0 7D [param] [value] F7` (manufacturer `0x7D`),
> velocity fixed 100.

---

## v1.1 — Presets & Low-Bass fix (2026-06-15)

This stretch added Protocol v1.1 **preset support** and fixed **inaudible bass**.
Both are **VST3-side only — no wire/protocol change**; Protocol stays v1.1 and the
two codebases remain in sync.

### 1. Preset support (SysEx `0x08`)
- New param `0x08 [id]` (0–49) selects a preset.
- **Division of responsibility (per PROTOCOL.md):** the **APK owns** preset
  id / name / category and the controller-visible params (oscillator, pulse
  width, Y target) — it sends `0x08 [id]` then `0x01/0x02/0x07`. The **VST3 owns
  the "deep patch"** for each id (ADSR + reverb/delay/tremolo/stereo + the
  octave shift below).
- A **50-patch table** lives in `Source/state/PresetTable.{h,cpp}`, authored by
  category (lead / pad / bass / keys / pluck / bell / brass / strings / organ /
  FX). Oscillator + Y target for each id match PROTOCOL.md's Preset Table exactly.
- Loading a preset **does not** change X-Axis Mode / Root Key / Scale / Octave
  Range (performer-owned), per spec.
- UI: the editor header shows **"Preset: <name>"**. Any manual edit on the VST
  side flips it to **"Custom"** (`SynthSettings::currentPreset` = −1). Selection
  is saved with the project.

### 2. Low-bass fix (octave shift)
- **Root cause:** PROTOCOL.md's X-axis encoding fixes the pad's lowest note at
  **MIDI 48 = C3 (~131 Hz)**, extending upward — so the APK can't send true bass
  and the engine had no low range.
- **Fix:** a VST3-only **octave shift** (`SynthSettings::octaveShift`, −3…+3),
  applied to the **synthesized frequency only** (the mirrored pad still shows the
  played note). Exposed as a saved "Oct Shift" slider, and baked into bass
  presets as part of their deep patch:
  - **Sub Bass −1 oct (~65 Hz)** — audible on normal monitors.
  - **Deep Sub −2 oct (~33 Hz)** — for subwoofer / full-range rigs.
  - other bass presets −1 oct; non-bass = 0.
- Why Sub Bass is only −1: a ~33 Hz pure sine is inaudible on typical speakers
  (below their roll-off, no harmonics to imply the pitch, and ear insensitivity
  down there). −1 keeps it audible; Deep Sub stays −2 for those with subs.
- Also fixed an editor sizing bug found along the way: the window was too short,
  so Delay FB/Wet, Tremolo Depth, and Stereo Spread were running off the bottom.
  Editor is now taller and all controls fit.

### Files touched
- `Source/ProtocolConstants.h` — `0x08` param + `kNumPresets = 50`
- `Source/state/PresetTable.{h,cpp}` — **new**, 50-patch table + `apply()`
- `Source/state/SynthSettings.{h,cpp}` — `currentPreset`, `octaveShift` + XML
- `Source/midi/SysExParser.cpp` — handle `0x08`
- `Source/synth/SynthVoice.{h,cpp}` — apply octave shift to frequency only
- `Source/ui/ControlPanel.{h,cpp}` — "Oct Shift" control, "Custom" on manual edit
- `Source/PluginEditor.{h,cpp}` — header preset-name display + taller window
- `CMakeLists.txt` — build `PresetTable.cpp` (plugin + test targets)
- `Tests/TestMain.cpp` — preset + octave-shift test coverage
- `TouchSynthSpec/SPEC_VST3.md` — documented v1.1 preset behavior

### Contract status
**No wire change.** Protocol stays **v1.1**. The octave shift is purely
VST3-internal (not a SysEx param). Both sides in sync: ch 2–16, ±48 bend @
`0x2000`, CC74, vel 100, SysEx `F0 7D … F7`, preset table `0x08`.

### Verification
- **Unit tests: 83/83 pass** — `TouchSynthTests.exe`. Covers preset-table
  integrity, osc/Y vs PROTOCOL.md, X/key/scale/octave preserved on load, octave
  shifts (Sub Bass −1, Deep Sub −2), out-of-range id rejected, connect-burst
  order, plus the existing MPE/SysEx/pitch-bend/CC74/oscillator suites.
- **Live in REAPER:** selecting *Sub Bass* on the tablet loads the correct patch
  (Sine, LP-filter Y, bass ADSR), header reads "Preset: Sub Bass", Oct Shift −1,
  audible. *Deep Sub* confirmed at −2.
- Deployed: `C:\Program Files\Common Files\VST3\TouchSynth.vst3`.

---

## Build / test / deploy

CMake isn't on PATH; use the VS Build Tools bundled CMake. JUCE 7.0.12 is pulled
via FetchContent (cached after first configure).

```powershell
$cmake = "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
$root  = "C:\Users\micha\Dropbox\TouchSynthVST3"

# configure (first time / after CMakeLists changes)
& $cmake -S $root -B "$root\build" -G "Visual Studio 17 2022" -A x64

# build everything (plugin + tests)
& $cmake --build "$root\build" --config Release

# run the headless test harness (exit 0 == all pass)
& "$root\build\TouchSynthTests_artefacts\Release\TouchSynthTests.exe"
```

**Deploy:** copy `build\TouchSynthVST3_artefacts\Release\VST3\TouchSynth.vst3`
to `C:\Program Files\Common Files\VST3\`. REAPER caches the loaded DLL in memory,
so **fully quit REAPER first** (removing the FX instance is not enough to release
the file lock), then copy, then relaunch.

**Tip:** the "Oct Shift" slider transposes any patch live (saved with the
project) — no rebuild/restart needed for octave tweaks.

---

## Open / optional next steps
- Save the REAPER smoke-test project so track + MIDI routing + plugin persist.
- Tablet USB persistence: set Developer options → Default USB Configuration →
  MIDI so it doesn't revert to charging/adb mode (the recurring "APK won't
  register" cause). Quick fix from PC if it reverts:
  `adb shell svc usb setFunctions midi`.
- Optional protocol question for the APK chat: whether to ever lower the *pad's*
  root note (a both-sides X-axis-encoding change). Deliberately avoided so far —
  the VST3 transpose covers synth audibility without touching the contract.
