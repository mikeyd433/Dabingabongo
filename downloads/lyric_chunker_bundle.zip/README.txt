Lyric Chunker bundle
====================

lyric_chunker.py — the Blender add-on. Install via Edit > Preferences >
  Add-ons > Install from Disk. Renders per-syllable chunk PNGs plus a
  Line#.json timing manifest per line.

generate_comp.py — the Fusion comp generator (needs Python 3, nothing
  else). Feed it the add-on's output and it writes a pasteable
  Line#.setting node graph per line:

      python generate_comp.py "C:\path\to\output_root"

  Open the .setting in a text editor, copy all, paste into the Fusion
  node area in DaVinci Resolve, and wire the last Merge to MediaOut.

Docs: https://github.com/mikeyd433/LyricChunker
