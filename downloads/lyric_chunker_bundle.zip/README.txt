Lyric Chunker bundle
====================

lyric_chunker.py — the Blender add-on. Install via Edit > Preferences >
  Add-ons > Install from Disk. Renders per-syllable chunk PNGs plus a
  Line#.json timing manifest per line.

generate_comp.py — the Fusion comp generator (needs Python 3, nothing
  else). Feed it the add-on's output and it writes a pasteable
  Line#.setting node graph per line:

      python generate_comp.py "C:\path\to\output_root"

  Open the .setting in a text editor, copy all, paste into the Fusion
  node area in DaVinci Resolve, and wire the last Merge to MediaOut.

Generate Comps.bat — no-terminal way to run the generator: drag your
  render output folder onto the .bat (or double-click it and paste the
  path when asked). The add-on's "Generate Fusion Comps" panel button
  does the same thing from inside Blender.

Docs: https://github.com/mikeyd433/LyricChunker
