# --------------------------------------------------------------------------
# GENERATED FILE — do not edit. Built from the lyric_chunker/ package by
# scripts/build_single_file.py. Edit the package modules instead.
# --------------------------------------------------------------------------
#!/usr/bin/env python3
"""Generate pasteable Fusion node graphs from Lyric Chunker manifests.

For each Line#.json manifest, writes a Line#.setting next to it (or to
--out-dir). Open the .setting in a text editor, copy everything, click
an empty spot in the Fusion node area, and paste — the chunk graph
appears with color-flip and bounce keyframed from the manifest timing.
Wire the last Merge to MediaOut to finish.

Usage:
    python3 scripts/generate_comp.py <output_root_or_manifest> [more...]
    python3 scripts/generate_comp.py Line16/Line16.json --clip-dir "C:\\path\\Line 16"

--clip-dir sets the folder Loader nodes point at, for when the comp
runs on a different machine than the one that rendered (paths are baked
into the Loaders). Defaults to each manifest's own folder.
"""

import argparse
import importlib.util
import sys
from pathlib import Path

# ===== manifest.py ================================================

"""JSON manifest read/write and output naming (spec addendum §1).

Pure logic, no bpy — unit-testable outside Blender.

One manifest per line, written into that line's output folder as
``Line<N>.json`` next to the chunk PNGs. ``manifest_version`` increments
on breaking schema change; never reuse a version number for a changed
shape. ``song.json`` at the output root is reserved for the v1.5
cross-line index — do not use that filename for anything else.
"""

import json

MANIFEST_VERSION = 1

# Single source of truth for the add-on version; blender_manifest.toml
# must match (the single-file build script asserts it).
ADDON_ID = "lyric_chunker"
ADDON_VERSION = "2.6.0"

RESERVED_FILENAMES = {"song.json"}


def fmt_num(n, pad):
    return f"{n:02d}" if pad else str(n)


def line_dirname(line_no, pad=False):
    return f"Line{fmt_num(line_no, pad)}"


def chunk_name(line_no, chunk_no, pad=False):
    return f"Line{fmt_num(line_no, pad)}_Chunk{fmt_num(chunk_no, pad)}"


def chunk_filename(line_no, chunk_no, pad=False):
    return chunk_name(line_no, chunk_no, pad) + ".png"


def manifest_filename(line_no, pad=False):
    return line_dirname(line_no, pad) + ".json"


def build_chunk_entry(
    index,
    name,
    text,
    filename,
    world_position,
    screen_position,
    bbox_px,
    offset_x,
    manual_offset_x=0.0,
    start_seconds=None,
    start_frame=None,
    timing_source="none",
):
    """One entry for the ``chunks`` array.

    ``start_seconds`` is the canonical timing value (survives fps
    changes); ``start_frame`` is derived convenience only. No end times —
    chunk visibility duration is a comp-side decision (§4.5).
    ``bbox_px`` is [x_min, y_min, x_max, y_max] with origin at
    bottom-left, matching Blender's camera view and Fusion.
    """
    return {
        "index": index,
        "name": name,
        "text": text,
        "filename": filename,
        "world_position": [round(v, 6) for v in world_position],
        "screen_position": [round(v, 6) for v in screen_position],
        "bbox_px": list(bbox_px),
        "offset_x": round(offset_x, 6),
        "manual_offset_x": round(manual_offset_x, 6),
        "start_seconds": None if start_seconds is None else round(start_seconds, 4),
        "start_frame": start_frame,
        "timing_source": timing_source,
    }


def build_manifest(
    generator,
    project,
    render,
    line,
    chunks,
    verification=None,
    rendered_at=None,
):
    return {
        "manifest_version": MANIFEST_VERSION,
        "generator": generator,
        "project": project,
        "render": render,
        "line": line,
        "chunks": chunks,
        "verification": verification or {"run": False},
        "rendered_at": rendered_at,
    }


def write_manifest(path, manifest):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2, ensure_ascii=False)
        fh.write("\n")


def read_manifest(path):
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    version = data.get("manifest_version")
    if version != MANIFEST_VERSION:
        raise ValueError(
            f"manifest_version {version!r} in {path} — this add-on reads "
            f"version {MANIFEST_VERSION}"
        )
    return data


def seconds_to_frame(seconds, fps, fps_base=1.0):
    """Derived start_frame; start_seconds stays the source of truth."""
    if seconds is None:
        return None
    return round(seconds * (fps / fps_base))


# ===== comp/reactor.py ============================================

"""Reactor elements — extra images that bounce on chunk timing.

The second consumer of the manifest (§1): anything that should react to
the vocal — a cut-out head, a logo, a prop rendered out of Blender —
reads the same per-chunk start frames the lyrics use, so timing is
captured once and drives everything.

An element is a transparent PNG plus a rule for *which* chunks it
reacts to. Two elements set to ``odd`` and ``even`` alternate; one
element set to ``all`` bounces on every chunk. ``enabled`` switches an
element off without deleting its configuration.

Config lives in ``elements.json`` at the render output root, beside the
Line#/ folders. Generation is otherwise identical to a lyric chunk:

    Loader -> Place (static position/size) -> Bounce (PolyPath) -> Merge

The bounce reuses the verified 3-point PolyPath, but an element bounces
many times in one line, so its Displacement spline alternates direction
each time — 0 -> 0.5 -> 1, then 1 -> 0.5 -> 0. Both ends of the path
are the rest position, so consecutive bounces need no reset key and the
element sits still between them.
"""

import os
import re

ELEMENTS_FILENAME = "elements.json"
ELEMENTS_VERSION = 1

DEFAULT_ELEMENT_DEPTH = 0.03
DEFAULT_ELEMENT_DIP_IN = 1
DEFAULT_ELEMENT_DIP_OUT = 3
DEFAULT_ELEMENT_POSITION = (0.5, 0.5)

_NAME_SAFE_RE = re.compile(r"[^A-Za-z0-9_]")


def template_elements():
    """Starter config: two heads alternating odd/even chunks.

    Switching to a single bouncing object is two edits — set one
    element's ``chunks`` to ``"all"`` and the other's ``enabled`` to
    false.
    """
    return {
        "elements_version": ELEMENTS_VERSION,
        "_readme": [
            "Elements bounce on chunk timing alongside the lyrics.",
            "image: transparent PNG, relative to this file or absolute.",
            "chunks: 'all', 'odd', 'even', or a list like [1, 3, 5] (1-based).",
            "lines: 'all' or a list of line numbers like [17, 18].",
            "position: normalized [x, y]; 0.5, 0.5 is frame centre.",
            "in_front: true to sit over the lyrics, false to sit behind.",
            "enabled: false switches an element off without deleting it.",
            "Two elements set to 'odd' and 'even' alternate; one set to",
            "'all' bounces on every chunk.",
            "Avoid names ending in digits (head1.png, head2.png) — Fusion",
            "may read those as an image sequence. Use head_left.png etc.",
        ],
        "elements": [
            {
                "name": "HeadLeft",
                "image": "elements/head_left.png",
                "chunks": "odd",
                "lines": "all",
                "position": [0.22, 0.35],
                "size": 1.0,
                "bounce_depth": DEFAULT_ELEMENT_DEPTH,
                "dip_in": DEFAULT_ELEMENT_DIP_IN,
                "dip_out": DEFAULT_ELEMENT_DIP_OUT,
                "in_front": False,
                "enabled": True,
            },
            {
                "name": "HeadRight",
                "image": "elements/head_right.png",
                "chunks": "even",
                "lines": "all",
                "position": [0.78, 0.35],
                "size": 1.0,
                "bounce_depth": DEFAULT_ELEMENT_DEPTH,
                "dip_in": DEFAULT_ELEMENT_DIP_IN,
                "dip_out": DEFAULT_ELEMENT_DIP_OUT,
                "in_front": False,
                "enabled": True,
            },
        ],
    }


def load_elements(path):
    """Read an elements.json. Returns ``(elements, warnings)`` with only
    the enabled entries; a missing file is not an error."""
    import json

    if not os.path.exists(path):
        return [], []
    with open(path, "r", encoding="utf-8") as fh:
        doc = json.load(fh)
    version = doc.get("elements_version")
    if version != ELEMENTS_VERSION:
        raise ValueError(
            f"elements_version {version!r} in {path} — this build reads "
            f"version {ELEMENTS_VERSION}"
        )
    warnings = []
    elements = []
    for index, element in enumerate(doc.get("elements", []), start=1):
        name = element.get("name") or f"Element{index}"
        if not element.get("enabled", True):
            continue
        if not element.get("image"):
            warnings.append(f"element '{name}' has no image — skipped")
            continue
        elements.append(element)
    return elements, warnings


def safe_name(name):
    cleaned = _NAME_SAFE_RE.sub("_", str(name)).strip("_")
    return cleaned or "Element"


def is_absolute(image):
    return os.path.isabs(image) or bool(re.match(r"^[A-Za-z]:", image))


def applies_to_line(element, line_no):
    lines = element.get("lines", "all")
    if isinstance(lines, str):
        return lines.lower() == "all"
    return line_no in lines


def chunk_indices(element, chunk_count):
    """0-based chunk indices this element reacts to."""
    selector = element.get("chunks", "all")
    if isinstance(selector, str):
        key = selector.lower()
        if key == "all":
            return list(range(chunk_count))
        if key == "odd":
            return [i for i in range(chunk_count) if i % 2 == 0]
        if key == "even":
            return [i for i in range(chunk_count) if i % 2 == 1]
        return []
    return [n - 1 for n in selector if 1 <= n <= chunk_count]


def displacement_keys(starts, dip_in, dip_out):
    """Alternating-direction bounce keys for one element.

    Each bounce traverses the 3-point path in the opposite direction to
    the last, so the element rests between bounces without a reset key.
    Bounces that would overlap the previous one are dropped.
    """
    keys = []
    warnings = []
    value = 0.0
    last_end = None
    for start in starts:
        if last_end is not None and start < last_end:
            warnings.append(
                f"bounce at frame {start} overlaps the previous one — skipped"
            )
            continue
        target = 1.0 - value
        end = start + dip_in + dip_out
        if keys and keys[-1][0] == start:
            keys.pop()
        keys.append((start, value))
        keys.append((start + dip_in, 0.5))
        keys.append((end, target))
        value = target
        last_end = end
    return keys, warnings


# ===== comp/settings_gen.py =======================================

"""Fusion node-graph generation from a line manifest (spec addendum §6).

Pure logic, no bpy — runs standalone (``scripts/generate_comp.py``) or
from inside Blender later.

Emits Fusion's clipboard ``.setting`` text: paste it into a Fusion comp
and the full per-chunk graph appears, replicating the reference
workflow captured from the Salizar_Brenda comp:

    Loader -> ColorGain -> Transform -> Merge chain

Per chunk, at its (line-local) start frame S:
  - ColorGain: Gain Green/Blue keyframed from (1.0, 1.0) at S to
    (0.4, 0.05) at S+1 — a one-frame flip from white to the highlight
    orange. Red and Alpha stay 1.0.
  - Transform: Center rides a 3-point PolyPath (rest, dip -0.015, rest)
    whose Displacement spline is keyed 0 -> 0.5 -> 1 at S, S+1, S+4 —
    byte-for-byte the structure of the hand-animated reference bounce.

Delivery is the §6.3 clipboard route. The reference comp uses MediaIn
nodes fed by the Media Pool; generated graphs use Loader nodes reading
the PNGs from disk, which avoids Media Pool IDs that cannot be
fabricated from outside Resolve. EXPERIMENTAL until pasted Loaders are
confirmed to render on the Fusion page of the target Resolve install —
if they do not, the fallback is pasting everything except the Loaders
and connecting Media Pool imports by hand.
"""

import re


DEFAULT_HIGHLIGHT_GAIN = (1.0, 0.4, 0.05)
DEFAULT_DIP_DEPTH = 0.015
DEFAULT_DIP_IN = 1
DEFAULT_DIP_OUT = 3

# ViewInfo grid spacing, roughly matching the hand-built reference layout.
_COL_X = 110.0
_ROW_Y = 33.0

# Loaders hold their still well past the line's own span (10 min at
# 24fps) so stretching the comp clip on the timeline never runs the
# image out.
LOADER_HOLD_PADDING = 14400

# With no timing data at all, chunks cascade across this many seconds
# (weighted by chunk length, like the SRT distribution) instead of all
# firing at frame 0. Real timing comes from markers or SRT.
DEFAULT_UNTIMED_SECONDS = 3.0
UNTIMED_MIN_WEIGHT = 2


def _join_clip_path(png_dir, filename):
    """Join using the clip dir's own separator style — the path is
    consumed by Resolve on the user's machine, not this one."""
    sep = "\\" if ("\\" in png_dir or re.match(r"^[A-Za-z]:", png_dir)) else "/"
    return png_dir.rstrip("/\\") + sep + filename


def _element_path(image, base_dir):
    """Element images may be absolute or relative to elements.json."""
    if is_absolute(image):
        return image
    sep = "\\" if ("\\" in base_dir or re.match(r"^[A-Za-z]:", base_dir)) else "/"
    tail = image.replace("/", sep).replace("\\", sep)
    return base_dir.rstrip("/\\") + sep + tail


def _lua_str(value):
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"') + '"'


def _num(value):
    text = f"{float(value):.6f}".rstrip("0").rstrip(".")
    return text if text else "0"


def line_local_frames(doc, untimed_seconds=DEFAULT_UNTIMED_SECONDS,
                      untimed_frames=None):
    """Per-chunk start frames relative to the line's own start, for
    comps that live on a per-line timeline clip starting at frame 0.

    Fully untimed lines get a length-weighted cascade across
    ``untimed_seconds`` — or exactly ``untimed_frames`` frames when
    given, which overrides the seconds value (§4.4-style scaffold). A
    partially timed line keeps its timed chunks; the untimed ones land
    at 0 with a warning.
    """
    warnings = []
    render = doc.get("render", {})
    fps = render.get("fps", 24) / render.get("fps_base", 1.0)
    line = doc.get("line", {})
    chunks = doc["chunks"]
    starts = [c.get("start_frame") for c in chunks]

    if all(s is None for s in starts):
        span = untimed_frames if untimed_frames else fps * untimed_seconds
        weights = [max(len(c.get("text", "")), UNTIMED_MIN_WEIGHT) for c in chunks]
        total = sum(weights)
        cursor = 0.0
        frames = []
        for w in weights:
            frames.append(round(cursor))
            cursor += span * (w / total)
        spread = (
            f"{untimed_frames} frames" if untimed_frames
            else f"{untimed_seconds:g}s"
        )
        warnings.append(
            f"no timing data — chunks spread across the first {spread} "
            "as a scaffold; use markers or an SRT for real timing"
        )
        return frames, warnings

    if line.get("start_seconds") is not None:
        base = round(line["start_seconds"] * fps)
    else:
        timed = [s for s in starts if s is not None]
        base = min(timed) if timed else 0
    frames = []
    for chunk, start in zip(chunks, starts):
        if start is None:
            warnings.append(
                f"{chunk['name']}: no timing (timing_source "
                f"{chunk.get('timing_source', 'none')!r}) — placed at frame 0"
            )
            frames.append(0)
        else:
            frames.append(max(0, start - base))
    return frames, warnings


def comp_length(doc, frames):
    render = doc.get("render", {})
    fps = render.get("fps", 24) / render.get("fps_base", 1.0)
    line = doc.get("line", {})
    if line.get("start_seconds") is not None and line.get("end_seconds") is not None:
        return max(1, round((line["end_seconds"] - line["start_seconds"]) * fps))
    return max(frames) + round(fps) if frames else round(fps)


def _loader(name, filename, length, pos, frame_index, clip_frames):
    """One chunk's Loader.

    Fusion resolves the numbered chunk PNGs into a single image
    sequence (``Line17_Chunk##``) and re-bases every Loader to its
    first frame, regardless of which file the Loader names — verified
    against Resolve 21. Each Loader therefore pins its own chunk by
    trimming to its 0-based ``frame_index`` in the ``clip_frames``-long
    sequence, held via ExtendLast."""
    length = length + LOADER_HOLD_PADDING
    return f"""\
\t\t{name} = Loader {{
\t\t\tClips = {{
\t\t\t\tClip {{
\t\t\t\t\tID = "Clip1",
\t\t\t\t\tFilename = {_lua_str(filename)},
\t\t\t\t\tFormatID = "PNGFormat",
\t\t\t\t\tLength = {clip_frames},
\t\t\t\t\tSaving = false,
\t\t\t\t\tTrimIn = {frame_index},
\t\t\t\t\tTrimOut = {frame_index},
\t\t\t\t\tExtendFirst = 0,
\t\t\t\t\tExtendLast = {length},
\t\t\t\t\tLoop = 1,
\t\t\t\t\tAspectMode = 0,
\t\t\t\t\tDepth = 0,
\t\t\t\t\tTimeCode = 0,
\t\t\t\t\tGlobalStart = 0,
\t\t\t\t\tGlobalEnd = {length}
\t\t\t\t}}
\t\t\t}},
\t\t\tInputs = {{
\t\t\t\t["Gamut.SLogVersion"] = Input {{ Value = FuID {{ "SLog2" }}, }},
\t\t\t\tPostMultiplyByAlpha = Input {{ Value = 1, }},
\t\t\t}},
\t\t\tViewInfo = OperatorInfo {{ Pos = {{ {_num(pos[0])}, {_num(pos[1])} }} }},
\t\t}},
"""


def _spline(name, color, keyframes, locked_y=False):
    flags = "Linear = true, LockedY = true" if locked_y else "Linear = true"
    frames = ",\n".join(
        f"\t\t\t\t[{frame}] = {{ {_num(value)}, Flags = {{ {flags} }} }}"
        for frame, value in keyframes
    )
    return f"""\
\t\t{name} = BezierSpline {{
\t\t\tSplineColor = {{ Red = {color[0]}, Green = {color[1]}, Blue = {color[2]} }},
\t\t\tKeyFrames = {{
{frames}
\t\t\t}}
\t\t}},
"""


def _color_gain(name, source, start, dip_in, highlight, pos):
    """ColorGain with Green/Blue gain keyframed white -> highlight."""
    parts = [f"""\
\t\t{name} = ColorGain {{
\t\t\tInputs = {{
\t\t\t\tInput = Input {{ SourceOp = {_lua_str(source)}, Source = "Output", }},
\t\t\t\tGainRed = Input {{ Value = {_num(highlight[0])}, }},
\t\t\t\tGainGreen = Input {{ SourceOp = {_lua_str(name + "_Green")}, Source = "Value", }},
\t\t\t\tGainBlue = Input {{ SourceOp = {_lua_str(name + "_Blue")}, Source = "Value", }},
\t\t\t}},
\t\t\tViewInfo = OperatorInfo {{ Pos = {{ {_num(pos[0])}, {_num(pos[1])} }} }},
\t\t}},
"""]
    parts.append(_spline(
        name + "_Green", (16, 164, 16),
        [(start, 1.0), (start + dip_in, highlight[1])],
    ))
    parts.append(_spline(
        name + "_Blue", (16, 16, 164),
        [(start, 1.0), (start + dip_in, highlight[2])],
    ))
    return "".join(parts)


def _place_transform(name, source, position, size, pos):
    """Static placement for an element that is not already full-frame.

    Full-frame elements (the recommended form, matching the chunk PNGs)
    need no placement at all — this is only emitted when a position or
    size is actually given."""
    return f"""\
\t\t{name} = Transform {{
\t\t\tInputs = {{
\t\t\t\tInput = Input {{ SourceOp = {_lua_str(source)}, Source = "Output", }},
\t\t\t\tCenter = Input {{ Value = {{ {_num(position[0])}, {_num(position[1])} }}, }},
\t\t\t\tSize = Input {{ Value = {_num(size)}, }},
\t\t\t}},
\t\t\tViewInfo = OperatorInfo {{ Pos = {{ {_num(pos[0])}, {_num(pos[1])} }} }},
\t\t}},
"""


def _bounce_transform(name, source, keys, depth, pos):
    """Transform whose Center rides a 3-point PolyPath (rest, -depth,
    rest), driven by an explicit Displacement key list — the exact
    structure of the reference comp's hand-animated bounce, so it edits
    identically in the spline editor."""
    path = name + "Path"
    return f"""\
\t\t{name} = Transform {{
\t\t\tInputs = {{
\t\t\t\tInput = Input {{ SourceOp = {_lua_str(source)}, Source = "Output", }},
\t\t\t\tCenter = Input {{ SourceOp = {_lua_str(path)}, Source = "Position", }},
\t\t\t}},
\t\t\tViewInfo = OperatorInfo {{ Pos = {{ {_num(pos[0])}, {_num(pos[1])} }} }},
\t\t}},
\t\t{path} = PolyPath {{
\t\t\tDrawMode = "InsertAndModify",
\t\t\tInputs = {{
\t\t\t\tDisplacement = Input {{
\t\t\t\t\tSourceOp = {_lua_str(path + "Displacement")},
\t\t\t\t\tSource = "Value",
\t\t\t\t}},
\t\t\t\tPolyLine = Input {{
\t\t\t\t\tValue = Polyline {{
\t\t\t\t\t\tPoints = {{
\t\t\t\t\t\t\t{{ Linear = true, LockY = true, X = 0, Y = 0 }},
\t\t\t\t\t\t\t{{ Linear = true, LockY = true, X = 0, Y = {_num(-depth)} }},
\t\t\t\t\t\t\t{{ Linear = true, LockY = true, X = 0, Y = 0 }}
\t\t\t\t\t\t}}
\t\t\t\t\t}},
\t\t\t\t}}
\t\t\t}},
\t\t}},
""" + _spline(path + "Displacement", (255, 0, 255), keys, locked_y=True)


def _transform(name, source, start, dip_in, dip_out, depth, pos):
    """A lyric chunk's single bounce at its start frame."""
    keys = [
        (start, 0.0),
        (start + dip_in, 0.5),
        (start + dip_in + dip_out, 1.0),
    ]
    return _bounce_transform(name, source, keys, depth, pos)


def _element_branch(element, base_dir, starts, length, row):
    """One reactor element: Loader -> optional Place -> Bounce."""
    name = safe_name(element.get("name"))
    y = row * _ROW_Y
    loader = f"Load_El_{name}"
    depth = float(element.get("bounce_depth", DEFAULT_ELEMENT_DEPTH))
    dip_in = int(element.get("dip_in", DEFAULT_ELEMENT_DIP_IN))
    dip_out = int(element.get("dip_out", DEFAULT_ELEMENT_DIP_OUT))
    position = tuple(element.get("position", DEFAULT_ELEMENT_POSITION))
    size = float(element.get("size", 1.0))

    # Element images are standalone files, so no sequence trimming.
    parts = [_loader(
        loader, _element_path(element["image"], base_dir), length,
        (0.0, y), frame_index=0, clip_frames=1,
    )]
    tip = loader
    if position != tuple(DEFAULT_ELEMENT_POSITION) or size != 1.0:
        place = f"Place_El_{name}"
        parts.append(_place_transform(place, tip, position, size, (_COL_X, y)))
        tip = place

    keys, warnings = displacement_keys(starts, dip_in, dip_out)
    warnings = [f"element '{name}': {w}" for w in warnings]
    if keys:
        bounce = f"Bounce_El_{name}"
        parts.append(_bounce_transform(bounce, tip, keys, depth, (2 * _COL_X, y)))
        tip = bounce
    return "".join(parts), tip, warnings


def _merge(name, background, foreground, pos):
    return f"""\
\t\t{name} = Merge {{
\t\t\tInputs = {{
\t\t\t\tBackground = Input {{ SourceOp = {_lua_str(background)}, Source = "Output", }},
\t\t\t\tForeground = Input {{ SourceOp = {_lua_str(foreground)}, Source = "Output", }},
\t\t\t\tPerformDepthMerge = Input {{ Value = 0, }},
\t\t\t}},
\t\t\tViewInfo = OperatorInfo {{ Pos = {{ {_num(pos[0])}, {_num(pos[1])} }} }},
\t\t}},
"""


def generate_line_setting(
    doc,
    png_dir,
    highlight=DEFAULT_HIGHLIGHT_GAIN,
    dip_depth=DEFAULT_DIP_DEPTH,
    dip_in=DEFAULT_DIP_IN,
    dip_out=DEFAULT_DIP_OUT,
    untimed_seconds=DEFAULT_UNTIMED_SECONDS,
    untimed_frames=None,
    elements=None,
    elements_dir=None,
):
    """Build the pasteable node-graph text for one line manifest.

    ``png_dir`` is the directory holding the chunk PNGs (normally the
    manifest's own folder). ``elements`` is the optional reactor element
    list (§ reactor.py), resolved against ``elements_dir``. Returns
    ``(text, warnings)``. The graph ends at the last Merge (or a single
    branch's tip) — wire that to MediaOut after pasting.
    """
    chunks = doc["chunks"]
    if not chunks:
        raise ValueError("manifest has no chunks")
    frames, warnings = line_local_frames(doc, untimed_seconds, untimed_frames)
    length = comp_length(doc, frames)
    line_no = doc["line"]["index"]

    behind, in_front = [], []
    for element in (elements or []):
        if not applies_to_line(element, line_no):
            continue
        (in_front if element.get("in_front") else behind).append(element)

    tools = []

    def add_elements(group, first_row):
        """Element branches, returning their tip names in order."""
        tips = []
        for offset, element in enumerate(group):
            starts = [
                frames[i] for i in chunk_indices(element, len(chunks))
            ]
            text, tip, element_warnings = _element_branch(
                element, elements_dir or png_dir, starts, length,
                first_row + offset,
            )
            tools.append(text)
            warnings.extend(element_warnings)
            tips.append(tip)
        return tips

    # Behind the lyrics first — the merge chain stacks in list order.
    back_tips = add_elements(behind, len(chunks))

    branch_tips = []
    for row, (chunk, start) in enumerate(zip(chunks, frames)):
        base = chunk["name"]
        y = row * _ROW_Y
        loader = f"Load_{base}"
        color = f"Color_{base}"
        move = f"Move_{base}"
        tools.append(_loader(
            loader, _join_clip_path(png_dir, chunk["filename"]), length,
            (0.0, y), frame_index=row, clip_frames=len(chunks),
        ))
        tools.append(_color_gain(color, loader, start, dip_in, highlight, (_COL_X, y)))
        tools.append(_transform(move, color, start, dip_in, dip_out, dip_depth, (2 * _COL_X, y)))
        branch_tips.append(move)

    front_tips = add_elements(in_front, len(chunks) + len(behind))
    ordered_tips = back_tips + branch_tips + front_tips

    current = ordered_tips[0]
    for i, tip in enumerate(ordered_tips[1:], start=1):
        merge = f"Merge_Line{line_no}_{i}"
        tools.append(_merge(
            merge, current, tip,
            (3 * _COL_X + i * 40.0, (i + 0.5) * _ROW_Y),
        ))
        current = merge

    text = (
        "{\n"
        "\tTools = ordered() {\n"
        + "".join(tools)
        + "\t},\n"
        f"\tActiveTool = {_lua_str(current)}\n"
        "}\n"
    )
    return text, warnings



def find_manifests(paths):
    for raw in paths:
        path = Path(raw)
        if path.is_dir():
            found = sorted(path.glob("Line*/Line*.json")) or sorted(
                path.glob("Line*.json")
            )
            if not found:
                sys.exit(f"no Line#.json manifests under {path}")
            yield from found
        else:
            yield path


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("paths", nargs="+",
                    help="Line#.json manifest(s), or an output root to scan")
    ap.add_argument("--out-dir", type=Path,
                    help="write .setting files here (default: next to each manifest)")
    ap.add_argument("--clip-dir",
                    help="folder the Loader nodes read PNGs from "
                         "(default: each manifest's folder)")
    ap.add_argument("--highlight", nargs=3, type=float, metavar=("R", "G", "B"),
                    default=list(DEFAULT_HIGHLIGHT_GAIN),
                    help="highlight gain, default 1.0 0.4 0.05 (the orange)")
    ap.add_argument("--dip-depth", type=float, default=DEFAULT_DIP_DEPTH,
                    help="bounce depth in normalized frame height, default 0.015")
    ap.add_argument("--dip-in", type=int, default=DEFAULT_DIP_IN,
                    help="frames from chunk start to full dip/color, default 1")
    ap.add_argument("--dip-out", type=int, default=DEFAULT_DIP_OUT,
                    help="frames to recover from the dip, default 3")
    ap.add_argument("--untimed-seconds", type=float,
                    default=DEFAULT_UNTIMED_SECONDS,
                    help="with no timing data, cascade chunks across this "
                         "many seconds (default 3)")
    ap.add_argument("--untimed-frames", type=int, default=None,
                    help="with no timing data, cascade chunks across exactly "
                         "this many frames (overrides --untimed-seconds)")
    ap.add_argument("--init-elements", action="store_true",
                    help="write a starter elements.json beside the manifests "
                         "and exit")
    args = ap.parse_args()

    if args.init_elements:
        import json
        root = Path(args.paths[0])
        root = root if root.is_dir() else root.parent
        target = root / ELEMENTS_FILENAME
        if target.exists():
            sys.exit(f"{target} already exists")
        (root / "elements").mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(template_elements(), indent=2) + "\n",
            encoding="utf-8",
        )
        print(f"wrote {target} — add element PNGs under {root / 'elements'}")
        return

    manifests = list(find_manifests(args.paths))
    elements_root = manifests[0].parent.parent if manifests else Path(".")
    elements, element_warnings = load_elements(
        str(elements_root / ELEMENTS_FILENAME)
    )
    for warning in element_warnings:
        print(f"  warning: {warning}")

    for manifest_path in manifests:
        doc = read_manifest(manifest_path)
        clip_dir = args.clip_dir or str(manifest_path.parent)
        text, warnings = generate_line_setting(
            doc,
            clip_dir,
            highlight=tuple(args.highlight),
            dip_depth=args.dip_depth,
            dip_in=args.dip_in,
            dip_out=args.dip_out,
            untimed_seconds=args.untimed_seconds,
            untimed_frames=args.untimed_frames,
            elements=elements,
            elements_dir=str(elements_root),
        )
        out_dir = args.out_dir or manifest_path.parent
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / (manifest_path.stem + ".setting")
        out.write_text(text, encoding="utf-8")
        print(f"wrote {out} ({len(doc['chunks'])} chunks)")
        for w in warnings:
            print(f"  warning: {w}")
    print(
        "\nPaste into Fusion: open the .setting in a text editor, copy all, "
        "click an empty spot in the node area, Ctrl+V, then wire the last "
        "Merge to MediaOut."
    )


if __name__ == "__main__":
    main()
