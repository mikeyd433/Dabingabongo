@echo off
setlocal
rem Drag your Lyric Chunker output folder onto this file to generate
rem pasteable Fusion comps (Line#.setting) next to every Line#.json.
if "%~1"=="" (
    echo Drag your render output folder onto this .bat to generate comps.
    set /p TARGET=Or paste the folder path here and press Enter:
) else (
    set "TARGET=%~1"
)
where python >nul 2>nul
if %errorlevel%==0 (
    python "%~dp0generate_comp.py" "%TARGET%"
) else (
    py "%~dp0generate_comp.py" "%TARGET%"
)
echo.
pause
